#define BLYNK_TEMPLATE_ID "TMPL3Z5tWKiLf"
#define BLYNK_TEMPLATE_NAME "Flame and gas detection"
#define BLYNK_AUTH_TOKEN "WJOG_x_nTa4AGppUtuvZaeSn8bQ3Qo5L"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

// IMPORTANT: Wokwi simulation requires these exact credentials to connect online
char ssid[] = "Wokwi-GUEST";          
char pass[] = "";          

// Exact pin matching from your Wokwi diagram:
#define MQ2_DOUT_PIN 32    // Green wire from blue MQ2 sensor DOUT
#define FLAME_PIN 35       // Green wire from black IR sensor DAT
#define BUZZER_PIN 25      // Green wire to the Buzzer
#define LED_PIN 26         // Green wire to the Red LED Anode

BlynkTimer timer;

// State tracking flags
bool gasAlertSent = false;
bool fireAlertSent = false;
bool alarmActive = false;
int alarmDurationCounter = 0; 
bool mobileMute = false;      
bool buzzerState = false;     

unsigned long dangerStartTime = 0;
bool dangerSustained = false;

// Blynk App Sync: Mute button widget on Virtual Pin V1
BLYNK_WRITE(V1) {
  int buttonState = param.asInt(); 
  if (buttonState == 1) {
    mobileMute = true;  
    digitalWrite(BUZZER_PIN, LOW); 
    digitalWrite(LED_PIN, LOW);
    Serial.println("📱 Alarm muted via Mobile App!");
  } else {
    mobileMute = false; 
  }
}

void checkSensors() {
  int flameValue = digitalRead(FLAME_PIN); 
  int gasValue = digitalRead(MQ2_DOUT_PIN); 
  
  // In Wokwi, the black IR module outputs LOW (0) when clicked/activated
  bool instantDangerPresent = (flameValue == LOW || gasValue == HIGH);

  // --- SUSTAINED DANGER DEBOUNCE ---
  if (instantDangerPresent) {
    if (dangerStartTime == 0) {
      dangerStartTime = millis(); 
    }
    // Threat must be continuous for 2 seconds to filter false positives
    if (millis() - dangerStartTime >= 2000) {
      dangerSustained = true; 
    }
  } else {
    dangerStartTime = 0;
    dangerSustained = false;
  }

  // --- EMERGENCY TRIGGER LOGIC ---
  if (dangerSustained) {
    if (!alarmActive) {
      alarmActive = true;
      alarmDurationCounter = 0; 
    }

    // Trigger unique notifications configured in your Blynk template settings
    if (gasValue == HIGH && !gasAlertSent) {
      Blynk.logEvent("gas_alert", "⚠️ Gas Detected!");
      gasAlertSent = true;
    }
    if (flameValue == LOW && !fireAlertSent) {
      Blynk.logEvent("fire_alert", "🔥 Fire Detected!");
      fireAlertSent = true;
    }

    // 1-Minute maximum hardware alert timeout (30 cycles * 2 seconds = 60 seconds)
    if (alarmDurationCounter < 30 && !mobileMute) {
      buzzerState = !buzzerState; 
      
      digitalWrite(BUZZER_PIN, buzzerState ? HIGH : LOW);
      digitalWrite(LED_PIN, buzzerState ? HIGH : LOW); 
      
      alarmDurationCounter++; 
    } else {
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(LED_PIN, LOW);
    }
  } else {
    // Everything is safe: reset flags and silence everything
    alarmActive = false;
    alarmDurationCounter = 0;
    gasAlertSent = false;
    fireAlertSent = false;
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
    
    if (mobileMute) {
      mobileMute = false;
      Blynk.virtualWrite(V1, 0); // Reset mobile button to OFF state
    }
  }
  
  // Serial diagnostics log
  Serial.print("Flame Sensor (DAT): "); Serial.print(flameValue == LOW ? "DETECTED " : "SAFE ");
  Serial.print("| Gas Sensor (DOUT): "); Serial.print(gasValue == HIGH ? "DETECTED " : "SAFE ");
  Serial.print("| Threat Status: "); Serial.println(dangerSustained ? "🚨 DANGER" : "✅ CLEAR");
  Serial.println("---------------------------------------------");
}

void setup() {
  Serial.begin(115200);

  pinMode(MQ2_DOUT_PIN, INPUT);  
  pinMode(FLAME_PIN, INPUT);     
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);

  Serial.println("Connecting to Blynk Simulation Network...");
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  // Runs sensor sweeps every 2 seconds
  timer.setInterval(2000L, checkSensors);
}

void loop() {
  Blynk.run();    
  timer.run();    
}
